
# Gestion Commerciale – Next.js (TypeScript)

App web moderne pour gérer **Produits, Clients, Fournisseurs, Ventes, Achats** avec **Tableau de bord** et **graphique des ventes mensuelles**.  
Aucune base de données requise : les données sont sauvegardées dans le **navigateur (localStorage)**. Vous pourrez brancher une API plus tard.

## Démarrage

```bash
# 1) Installer les dépendances
npm install

# 2) Lancer en dev
npm run dev

# 3) Ouvrir
http://localhost:3000
```

## Paliers / Améliorations possibles
- Authentification (Clerk/Auth.js) et multi-utilisateurs
- Backend (Supabase/Firebase/Express) au lieu de localStorage
- Impression facture & export PDF
- Rôles (admin/vendeur), remises, dettes clients
- Import/Export CSV
- Multi-devises et taxes

---

**Astuce** : les données de démonstration apparaissent après avoir ouvert les pages **Produits / Clients / Fournisseurs** (elles se chargent si votre base locale est vide).


## Activer la base de données (Supabase)

1. Créez un projet sur https://supabase.com
2. Dans **Project Settings → API**, copiez **Project URL** et **anon public key**.
3. Renommez `.env.local.example` en `.env.local` et remplissez :
```
NEXT_PUBLIC_SUPABASE_URL=... 
NEXT_PUBLIC_SUPABASE_ANON_KEY=...
```
4. Dans **SQL Editor**, collez le contenu de `supabase_schema.sql` puis exécutez.
5. Redémarrez le serveur (`npm run dev`).  
   - Si les variables d'env sont présentes, l'app utilise **Supabase**.  
   - Sinon, elle reste en **localStorage** (mode hors-ligne).
