
"use client";
import { useEffect, useState } from "react";
import { supabase, hasSupabase } from "./supabase";

export function useTable<T extends { id: string }>(
  key: string,
  initial: T[] = []
) {
  const [rows, setRows] = useState<T[]>(initial);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  // Fetch on mount
  useEffect(() => {
    (async () => {
      try {
        if (hasSupabase) {
          const { data, error } = await supabase.from(key).select("*").order("id");
          if (error) throw error;
          setRows((data as T[]) || []);
        } else {
          const raw = localStorage.getItem(key);
          setRows(raw ? (JSON.parse(raw) as T[]) : initial);
        }
      } catch (e:any) {
        setError(e.message || String(e));
      } finally {
        setLoading(false);
      }
    })();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Persist local if not using supabase
  useEffect(() => {
    if (!hasSupabase) {
      try { localStorage.setItem(key, JSON.stringify(rows)); } catch {}
    }
  }, [key, rows]);

  async function insert(row: T) {
    if (hasSupabase) {
      const { data, error } = await supabase.from(key).insert(row).select();
      if (error) throw error;
      setRows(prev => [...prev, ...(data as T[])]);
    } else {
      setRows(prev => [...prev, row]);
    }
  }

  async function update(row: T) {
    if (hasSupabase) {
      const { data, error } = await supabase.from(key).upsert(row).select();
      if (error) throw error;
      setRows(prev => prev.map(r => (r.id === row.id ? (data?.[0] as T) || row : r)));
    } else {
      setRows(prev => prev.map(r => (r.id === row.id ? row : r)));
    }
  }

  async function remove(id: string) {
    if (hasSupabase) {
      const { error } = await supabase.from(key).delete().eq("id", id);
      if (error) throw error;
    }
    setRows(prev => prev.filter(r => r.id !== id));
  }

  return { rows, setRows, loading, error, insert, update, remove, hasSupabase };
}
