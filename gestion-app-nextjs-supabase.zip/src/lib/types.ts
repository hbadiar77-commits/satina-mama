
export type Product = { id: string; name: string; sku?: string; category?: string; price: number; cost?: number; stock: number; unit?: string };
export type Client = { id: string; name: string; phone?: string; email?: string; address?: string };
export type Supplier = { id: string; name: string; phone?: string; email?: string };
export type SaleItem = { productId: string; qty: number; price: number };
export type Sale = { id: string; date: string; clientId: string; items: SaleItem[] };
export type PurchaseItem = { productId: string; qty: number; cost: number };
export type Purchase = { id: string; date: string; supplierId: string; items: PurchaseItem[] };
