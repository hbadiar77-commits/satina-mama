
import { uid } from "./utils";
import type { Product, Client, Supplier } from "./types";

export const seedProducts: Product[] = [
  { id: uid("p"), name: "Oignon sac 25kg", sku: "ON25", category: "Épicerie", price: 320000, cost: 280000, stock: 18, unit: "sac" },
  { id: uid("p"), name: "Riz 50kg", sku: "RIZ50", category: "Céréales", price: 650000, cost: 590000, stock: 12, unit: "sac" },
  { id: uid("p"), name: "Sucre 50kg", sku: "SUG50", category: "Épicerie", price: 540000, cost: 490000, stock: 9, unit: "sac" },
];

export const seedClients: Client[] = [
  { id: uid("c"), name: "Boutique Alim. Diallo", phone: "+224600000001" },
  { id: uid("c"), name: "Marché Madina – Box 12" },
];

export const seedSuppliers: Supplier[] = [
  { id: uid("s"), name: "Grossiste Matam" },
  { id: uid("s"), name: "Import SA" },
];
