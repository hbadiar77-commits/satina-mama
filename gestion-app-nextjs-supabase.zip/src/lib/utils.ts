
export const uid = (prefix = "id") => `${prefix}_${Math.random().toString(36).slice(2,9)}`;
export const fmt = new Intl.NumberFormat("fr-FR");
export const gnf = (n: number) => `${fmt.format(n)} GNF`;
