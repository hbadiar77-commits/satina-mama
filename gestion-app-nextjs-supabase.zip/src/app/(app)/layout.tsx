
"use client";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { Package, ShoppingCart, Users, Truck, LayoutDashboard } from "lucide-react";

const links = [
  { href: "/dashboard", label: "Tableau de bord", icon: LayoutDashboard },
  { href: "/products", label: "Produits", icon: Package },
  { href: "/clients", label: "Clients", icon: Users },
  { href: "/suppliers", label: "Fournisseurs", icon: Truck },
  { href: "/sales", label: "Ventes", icon: ShoppingCart },
  { href: "/purchases", label: "Achats", icon: Truck },
];

export default function AppLayout({ children }: { children: React.ReactNode }){
  const pathname = usePathname();
  return (
    <div>
      <header className="border-b border-neutral-800 sticky top-0 backdrop-blur bg-[rgba(11,12,16,0.6)]">
        <div className="container flex items-center justify-between">
          <div className="flex items-center gap-3 py-3">
            <span className="inline-flex items-center justify-center w-9 h-9 rounded-xl bg-white text-black font-bold">GC</span>
            <h1 className="text-lg font-semibold">Gestion Commerciale</h1>
          </div>
          <nav className="flex gap-1">
            {links.map(l => {
              const Icon = l.icon;
              const active = pathname === l.href;
              return (
                <Link key={l.href} className={`nav ${active ? "active" : ""}`} href={l.href}>
                  <span className="inline-flex items-center gap-2"><Icon className="w-4 h-4"/>{l.label}</span>
                </Link>
              );
            })}
          </nav>
        </div>
      </header>
      <main className="container py-6">{children}</main>
      <footer className="container py-6 text-center text-neutral-400">© {new Date().getFullYear()} Gestion Commerciale</footer>
    </div>
  );
}
