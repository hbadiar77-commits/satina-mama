
"use client";
import { useMemo, useState } from "react";
import type { Product, Client, Sale, SaleItem } from "@/lib/types";
import { useLocal } from "@/lib/storage";
import { useTable } from "@/lib/data";
import { supabase, hasSupabase } from "@/lib/supabase";
import { uid, gnf } from "@/lib/utils";

export default function SalesPage(){
  const cloudProducts = useTable<Product>("products", []);
const [products, setProducts] = cloudProducts ? [cloudProducts.rows, cloudProducts.setRows] as const : useLocal<Product[]>("app_products", []);
  const cloudClients = useTable<Client>("clients", []);
const [clients] = cloudClients ? [cloudClients.rows] as const : useLocal<Client[]>("app_clients", []);
  const cloudSales = useTable<Sale>("sales", []);
const [sales, setSales] = cloudSales ? [cloudSales.rows, cloudSales.setRows] as const : useLocal<Sale[]>("app_sales", []);
  const [date, setDate] = useState<string>(new Date().toISOString().slice(0,10));
  const [clientId, setClientId] = useState<string>("");
  const [items, setItems] = useState<SaleItem[]>([]);

  function addLine(){
    if (!products.length) return;
    const p = products[0];
    setItems(prev => [...prev, { productId: p.id, qty: 1, price: p.price }]);
  }
  function update(idx:number, field:keyof SaleItem, val:any){
    const next = [...items];
    (next[idx] as any)[field] = field === "qty" || field === "price" ? Number(val) : val;
    if (field === "productId"){
      const p = products.find(x => x.id === val);
      if (p) (next[idx] as any).price = p.price;
    }
    setItems(next);
  }
  function remove(idx:number){
    const next = [...items]; next.splice(idx,1); setItems(next);
  }
  function save(){
    if (!items.length) return;
    const sale: Sale = { id: uid("sale"), date, clientId: clientId || (clients[0]?.id || uid("c")), items };
    if (cloudSales) { await cloudSales.insert(sale as any); } else { setSales([...(sales||[]), sale]); }
    // decrement stock for sold products
    setProducts(products.map(p => {
      const sold = items.filter(i => i.productId === p.id).reduce((t,i)=> t+i.qty, 0);
      return sold ? { ...p, stock: Math.max(0, p.stock - sold) } : p;
    }));
    if (hasSupabase) {
  // also store sale items in sales_items table for reporting
  const itemsRows = items.map(i => ({ id: uid('salei'), sale_id: sale.id, product_id: i.productId, qty: i.qty, price: i.price }));
  await supabase.from('sales_items').insert(itemsRows);
}
setItems([]);
  }

  const total = useMemo(() => items.reduce((t,i)=> t + i.qty * i.price, 0), [items]);

  return (
    <div className="space-y-6">
      <h2 className="text-xl font-semibold">Ventes</h2>
      <div className="card p-5 space-y-3">
        <div className="grid sm:grid-cols-3 gap-3">
          <div>
            <label className="block mb-1 text-sm">Date</label>
            <input className="input" type="date" value={date} onChange={e=>setDate(e.target.value)} />
          </div>
          <div>
            <label className="block mb-1 text-sm">Client</label>
            <select className="input" value={clientId} onChange={e=>setClientId(e.target.value)}>
              <option value="">— choisir —</option>
              {clients.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
            </select>
          </div>
          <div className="flex items-end"><button className="btn btn-primary" onClick={addLine}>Ajouter ligne</button></div>
        </div>

        <div className="overflow-x-auto">
          <table className="table w-full text-sm">
            <thead>
              <tr>
                <th>Produit</th><th className="text-right">PU</th><th className="text-right">Qté</th><th className="text-right">Total</th><th>—</th>
              </tr>
            </thead>
            <tbody>
              {items.map((it, idx) => {
                const p = products.find(x => x.id === it.productId);
                return (
                  <tr key={idx}>
                    <td>
                      <select className="input" value={it.productId} onChange={e=>update(idx, "productId", e.target.value)}>
                        {products.map(pp => <option key={pp.id} value={pp.id}>{pp.name}</option>)}
                      </select>
                    </td>
                    <td><input className="input text-right" type="number" value={it.price} onChange={e=>update(idx, "price", e.target.value)} /></td>
                    <td><input className="input text-right" type="number" value={it.qty} onChange={e=>update(idx, "qty", e.target.value)} /></td>
                    <td className="text-right">{gnf(it.qty * it.price)}</td>
                    <td><button className="btn" onClick={()=>remove(idx)}>Supprimer</button></td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>

        <div className="flex items-center justify-between">
          <div className="text-lg font-semibold">Total: {gnf(total)}</div>
          <div className="flex gap-2">
            <button className="btn" onClick={()=>setItems([])}>Vider</button>
            <button className="btn btn-primary" onClick={save}>Enregistrer</button>
          </div>
        </div>
      </div>

      {sales && sales.length > 0 && (
        <div className="card p-5">
          <h3 className="text-lg font-semibold mb-3">Historique</h3>
          <table className="table w-full text-sm">
            <thead><tr><th>Date</th><th>Client</th><th>Détails</th><th className="text-right">Montant</th></tr></thead>
            <tbody>
              {sales.map(s => (
                <tr key={s.id}>
                  <td>{s.date}</td>
                  <td>{clients.find(c => c.id === s.clientId)?.name || "—"}</td>
                  <td>{s.items.map(i => (products.find(p => p.id===i.productId)?.name || "") + " x" + i.qty).join(", ")}</td>
                  <td className="text-right">{gnf(s.items.reduce((t,i)=> t + i.qty*i.price, 0))}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
