
"use client";
import { useMemo, useState } from "react";
import type { Product, Supplier, Purchase, PurchaseItem } from "@/lib/types";
import { useLocal } from "@/lib/storage";
import { useTable } from "@/lib/data";
import { supabase, hasSupabase } from "@/lib/supabase";
import { uid, gnf } from "@/lib/utils";

export default function PurchasesPage(){
  const cloudProducts = useTable<Product>("products", []);
const [products, setProducts] = cloudProducts ? [cloudProducts.rows, cloudProducts.setRows] as const : useLocal<Product[]>("app_products", []);
  const cloudSuppliers = useTable<Supplier>("suppliers", []);
const [suppliers] = cloudSuppliers ? [cloudSuppliers.rows] as const : useLocal<Supplier[]>("app_suppliers", []);
  const cloudPurchases = useTable<Purchase>("purchases", []);
const [purchases, setPurchases] = cloudPurchases ? [cloudPurchases.rows, cloudPurchases.setRows] as const : useLocal<Purchase[]>("app_purchases", []);
  const [date, setDate] = useState<string>(new Date().toISOString().slice(0,10));
  const [supplierId, setSupplierId] = useState<string>("");
  const [items, setItems] = useState<PurchaseItem[]>([]);

  function addLine(){
    if (!products.length) return;
    const p = products[0];
    setItems(prev => [...prev, { productId: p.id, qty: 1, cost: p.cost ?? Math.round(p.price * 0.8) }]);
  }
  function update(idx:number, field:keyof PurchaseItem, val:any){
    const next = [...items];
    (next[idx] as any)[field] = field === "qty" || field === "cost" ? Number(val) : val;
    if (field === "productId"){
      const p = products.find(x => x.id === val);
      if (p) (next[idx] as any).cost = p.cost ?? Math.round(p.price * 0.8);
    }
    setItems(next);
  }
  function remove(idx:number){
    const next = [...items]; next.splice(idx,1); setItems(next);
  }
  function save(){
    if (!items.length) return;
    const pur: Purchase = { id: uid("buy"), date, supplierId: supplierId || (suppliers[0]?.id || uid("s")), items };
    if (cloudPurchases) { await cloudPurchases.insert(pur as any); } else { setPurchases([...(purchases||[]), pur]); }
    // increment stock
    setProducts(products.map(p => {
      const bought = items.filter(i => i.productId === p.id).reduce((t,i)=> t+i.qty, 0);
      return bought ? { ...p, stock: p.stock + bought } : p;
    }));
    if (hasSupabase) {
  const itemsRows = items.map(i => ({ id: uid('buyi'), purchase_id: pur.id, product_id: i.productId, qty: i.qty, cost: i.cost }));
  await supabase.from('purchases_items').insert(itemsRows);
}
setItems([]);
  }

  const total = useMemo(() => items.reduce((t,i)=> t + i.qty * i.cost, 0), [items]);

  return (
    <div className="space-y-6">
      <h2 className="text-xl font-semibold">Achats</h2>
      <div className="card p-5 space-y-3">
        <div className="grid sm:grid-cols-3 gap-3">
          <div>
            <label className="block mb-1 text-sm">Date</label>
            <input className="input" type="date" value={date} onChange={e=>setDate(e.target.value)} />
          </div>
          <div>
            <label className="block mb-1 text-sm">Fournisseur</label>
            <select className="input" value={supplierId} onChange={e=>setSupplierId(e.target.value)}>
              <option value="">— choisir —</option>
              {suppliers.map(s => <option key={s.id} value={s.id}>{s.name}</option>)}
            </select>
          </div>
          <div className="flex items-end"><button className="btn btn-primary" onClick={addLine}>Ajouter ligne</button></div>
        </div>

        <div className="overflow-x-auto">
          <table className="table w-full text-sm">
            <thead>
              <tr>
                <th>Produit</th><th className="text-right">Coût</th><th className="text-right">Qté</th><th className="text-right">Total</th><th>—</th>
              </tr>
            </thead>
            <tbody>
              {items.map((it, idx) => (
                  <tr key={idx}>
                    <td>
                      <select className="input" value={it.productId} onChange={e=>update(idx, "productId", e.target.value)}>
                        {products.map(pp => <option key={pp.id} value={pp.id}>{pp.name}</option>)}
                      </select>
                    </td>
                    <td><input className="input text-right" type="number" value={it.cost} onChange={e=>update(idx, "cost", e.target.value)} /></td>
                    <td><input className="input text-right" type="number" value={it.qty} onChange={e=>update(idx, "qty", e.target.value)} /></td>
                    <td className="text-right">{gnf(it.qty * it.cost)}</td>
                    <td><button className="btn" onClick={()=>remove(idx)}>Supprimer</button></td>
                  </tr>
              ))}
            </tbody>
          </table>
        </div>

        <div className="flex items-center justify-between">
          <div className="text-lg font-semibold">Total: {gnf(total)}</div>
          <div className="flex gap-2">
            <button className="btn" onClick={()=>setItems([])}>Vider</button>
            <button className="btn btn-primary" onClick={save}>Enregistrer</button>
          </div>
        </div>
      </div>

      {purchases && purchases.length > 0 && (
        <div className="card p-5">
          <h3 className="text-lg font-semibold mb-3">Historique</h3>
          <table className="table w-full text-sm">
            <thead><tr><th>Date</th><th>Fournisseur</th><th>Détails</th><th className="text-right">Montant</th></tr></thead>
            <tbody>
              {purchases.map(s => (
                <tr key={s.id}>
                  <td>{s.date}</td>
                  <td>{suppliers.find(c => c.id === s.supplierId)?.name || "—"}</td>
                  <td>{s.items.map(i => (products.find(p => p.id===i.productId)?.name || "") + " x" + i.qty).join(", ")}</td>
                  <td className="text-right">{gnf(s.items.reduce((t,i)=> t + i.qty*i.cost, 0))}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
