
"use client";
import CrudTable from "@/components/CrudTable";
import type { Product } from "@/lib/types";
import { seedProducts } from "@/lib/seed";

export default function ProductsPage(){
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-xl font-semibold">Produits</h2>
      </div>
      <CrudTable<Product>
        title="Inventaire"
        storageKey="app_products" dataKey="products"
        columns={[
          { key: "name", label: "Nom" },
          { key: "sku", label: "SKU" },
          { key: "category", label: "Catégorie" },
          { key: "unit", label: "Unité" },
          { key: "price", label: "Prix (GNF)", type: "number" },
          { key: "cost", label: "Coût (GNF)", type: "number" },
          { key: "stock", label: "Stock", type: "number" },
        ]}
        createEmpty={() => ({ id: "", name: "", price: 0, cost: 0, stock: 0, unit: "u" }) as Product}
        prefill={seedProducts as Product[]}
        moneyKeys={["price", "cost"] as (keyof Product)[]}
      />
    </div>
  );
}
