
"use client";
import CrudTable from "@/components/CrudTable";
import type { Client } from "@/lib/types";
import { seedClients } from "@/lib/seed";

export default function ClientsPage(){
  return (
    <div className="space-y-6">
      <h2 className="text-xl font-semibold">Clients</h2>
      <CrudTable<Client>
        title="Carnet clients"
        storageKey="app_clients" dataKey="clients"
        columns={[
          { key: "name", label: "Nom" },
          { key: "phone", label: "Téléphone" },
          { key: "email", label: "Email" },
          { key: "address", label: "Adresse" },
        ]}
        createEmpty={() => ({ id: "", name: "", phone: "", email: "", address: "" }) as Client}
        prefill={seedClients as Client[]}
      />
    </div>
  );
}
