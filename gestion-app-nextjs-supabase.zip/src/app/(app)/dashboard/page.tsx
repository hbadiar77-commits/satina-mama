
"use client";
import { useMemo } from "react";
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer } from "recharts";
import { gnf } from "@/lib/utils";
import { useLocal } from "@/lib/storage";
import type { Product, Sale, Client, Supplier, Purchase } from "@/lib/types";
import { Package, ShoppingCart, Users, Truck } from "lucide-react";

export default function Dashboard(){
  const [products] = useLocal<Product[]>("app_products", []);
  const [sales] = useLocal<Sale[]>("app_sales", []);
  const [clients] = useLocal<Client[]>("app_clients", []);
  const [suppliers] = useLocal<Supplier[]>("app_suppliers", []);
  const [purchases] = useLocal<Purchase[]>("app_purchases", []);

  const revenue = useMemo(() => sales.reduce((sum, s) => sum + s.items.reduce((ss, it) => ss + it.price * it.qty, 0), 0), [sales]);
  const stockValue = useMemo(() => products.reduce((sum, p) => sum + (p.cost ?? p.price * 0.8) * p.stock, 0), [products]);

  const chartData = useMemo(() => {
    const map = new Map<string, number>();
    sales.forEach(s => {
      const k = s.date.slice(0, 7);
      const amount = s.items.reduce((t, it) => t + it.qty * it.price, 0);
      map.set(k, (map.get(k) || 0) + amount);
    });
    return Array.from(map.entries()).map(([month, total]) => ({ month, total }));
  }, [sales]);

  const lowStock = useMemo(() => products.filter(p => p.stock <= 3), [products]);

  return (
    <div className="space-y-6">
      <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <Stat icon={<ShoppingCart className="w-5 h-5" />} title="Chiffre d’affaires" value={gnf(revenue)} sub="Total cumulé" />
        <Stat icon={<Package className="w-5 h-5" />} title="Valeur du stock" value={gnf(stockValue)} sub="Coût estimé" />
        <Stat icon={<Users className="w-5 h-5" />} title="Clients" value={String(clients.length)} sub="Actifs" />
        <Stat icon={<Truck className="w-5 h-5" />} title="Fournisseurs" value={String(suppliers.length)} sub="Partenaires" />
      </div>

      <div className="card p-6">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-semibold">Ventes mensuelles</h3>
        </div>
        <div className="h-72">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={chartData}>
              <XAxis dataKey="month" />
              <YAxis />
              <Tooltip formatter={(v: any) => gnf(Number(v))} />
              <Bar dataKey="total" />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      {lowStock.length > 0 && (
        <div className="card p-6">
          <h3 className="text-lg font-semibold mb-3">Ruptures proches</h3>
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-3">
            {lowStock.map(p => (
              <div key={p.id} className="flex items-center justify-between p-3 rounded-xl border border-neutral-800">
                <div>
                  <div className="font-medium">{p.name}</div>
                  <div className="text-xs text-neutral-400">Stock: {p.stock} {p.unit || "u"}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

function Stat({ icon, title, value, sub }:{ icon: React.ReactNode; title: string; value: string; sub?: string }){
  return (
    <div className="card p-5 flex items-center gap-4">
      <div className="muted w-11 h-11 rounded-xl flex items-center justify-center">{icon}</div>
      <div>
        <div className="text-sm text-neutral-400">{title}</div>
        <div className="text-2xl font-semibold leading-tight">{value}</div>
        {sub && <div className="text-xs text-neutral-500 mt-1">{sub}</div>}
      </div>
    </div>
  );
}
