
"use client";
import CrudTable from "@/components/CrudTable";
import type { Supplier } from "@/lib/types";
import { seedSuppliers } from "@/lib/seed";

export default function SuppliersPage(){
  return (
    <div className="space-y-6">
      <h2 className="text-xl font-semibold">Fournisseurs</h2>
      <CrudTable<Supplier>
        title="Fournisseurs"
        storageKey="app_suppliers" dataKey="suppliers"
        columns={[
          { key: "name", label: "Nom" },
          { key: "phone", label: "Téléphone" },
          { key: "email", label: "Email" },
        ]}
        createEmpty={() => ({ id: "", name: "", phone: "", email: "" }) as Supplier}
        prefill={seedSuppliers as Supplier[]}
      />
    </div>
  );
}
