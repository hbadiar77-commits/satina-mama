
"use client";
import { useEffect } from "react";
import { useLocal } from "@/lib/storage";
import { uid, gnf } from "@/lib/utils";

import { useTable } from "@/lib/data";

type Props<T> = {
  title: string;
  storageKey: string;
  columns: { key: keyof T, label: string, type?: string }[];
  createEmpty: () => T;
  prefill?: T[];
  moneyKeys?: (keyof T)[];
  dataKey?: string,
};

export default function CrudTable<T extends { id: string }>({ title, storageKey, columns, createEmpty, prefill, moneyKeys = [] }: Props<T>){
  const cloud = dataKey ? useTable<T>(dataKey, [] as T[]) : null as any;
const [rows, setRows] = cloud ? [cloud.rows, cloud.setRows] as const : useLocal<T[]>(storageKey, [] as T[]);

  useEffect(() => {
    if ((!rows || rows.length === 0) && prefill && prefill.length){
      setRows(prefill);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  function addRow(){
    const r = createEmpty();
    (r as any).id = uid("row");
    if (cloud) { cloud.insert(r as any); } else { setRows([...(rows||[]), r]); }
  }
  async function updateRow(idx: number, key: keyof T, val: any){
    const next = [...rows];
    (next[idx] as any)[key] = typeof (next[idx] as any)[key] === "number" ? Number(val) : val;
    if (cloud) { await cloud.update(next[idx] as any); } else { setRows(next); }
  }
  async function removeRow(idx: number){
    const next = [...rows];
    next.splice(idx, 1);
    if (cloud) { await cloud.update(next[idx] as any); } else { setRows(next); }
  }

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between">
        <h3 className="text-lg font-semibold">{title}</h3>
        <div className="flex gap-2">
          <button className="btn btn-secondary" onClick={() => setRows([])}>Vider</button>
          <button className="btn btn-primary" onClick={addRow}>Ajouter</button>
        </div>
      </div>
      <div className="overflow-x-auto card">
        <table className="table w-full text-sm">
          <thead>
            <tr>
              {columns.map(c => (<th key={String(c.key)} className="text-left">{c.label}</th>))}
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {(rows||[]).map((r, idx) => (
              <tr key={(r as any).id}>
                {columns.map(c => {
                  const v:any = (r as any)[c.key] ?? "";
                  const type = c.type || (typeof v === "number" ? "number" : "text");
                  return (
                    <td key={String(c.key)}>
                      <input className="input" type={type} value={v} onChange={e => updateRow(idx, c.key, e.target.value)} />
                    </td>
                  );
                })}
                <td>
                  <button className="btn" onClick={() => removeRow(idx)}>Supprimer</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      {moneyKeys.length > 0 && rows && rows.length > 0 && (
        <small className="helper">Champs monétaires: {moneyKeys.map(k => String(k)).join(", ")} (affichage: {gnf(123456)})</small>
      )}
    </div>
  );
}
