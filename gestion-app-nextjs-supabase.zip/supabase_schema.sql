
-- Créez un nouveau projet Supabase, puis exécutez ce SQL dans le SQL Editor.
-- Tables de base
create table if not exists products (
  id text primary key,
  name text not null,
  sku text,
  category text,
  unit text,
  price numeric not null,
  cost numeric,
  stock integer not null default 0,
  inserted_at timestamp with time zone default now()
);

create table if not exists clients (
  id text primary key,
  name text not null,
  phone text,
  email text,
  address text
);

create table if not exists suppliers (
  id text primary key,
  name text not null,
  phone text,
  email text
);

create table if not exists sales (
  id text primary key,
  date text not null,
  client_id text references clients(id) on delete set null
);

create table if not exists sales_items (
  id text primary key,
  sale_id text references sales(id) on delete cascade,
  product_id text references products(id) on delete set null,
  qty integer not null,
  price numeric not null
);

create table if not exists purchases (
  id text primary key,
  date text not null,
  supplier_id text references suppliers(id) on delete set null
);

create table if not exists purchases_items (
  id text primary key,
  purchase_id text references purchases(id) on delete cascade,
  product_id text references products(id) on delete set null,
  qty integer not null,
  cost numeric not null
);

-- Activer RLS et règles simples (accès lecture/écriture pour utilisateurs connectés)
alter table products enable row level security;
alter table clients enable row level security;
alter table suppliers enable row level security;
alter table sales enable row level security;
alter table sales_items enable row level security;
alter table purchases enable row level security;
alter table purchases_items enable row level security;

create policy "auth read" on products for select using (auth.role() = 'authenticated');
create policy "auth write" on products for insert with check (auth.role() = 'authenticated');
create policy "auth update" on products for update using (auth.role() = 'authenticated');
create policy "auth delete" on products for delete using (auth.role() = 'authenticated');

create policy "auth read" on clients for select using (auth.role() = 'authenticated');
create policy "auth write" on clients for insert with check (auth.role() = 'authenticated');
create policy "auth update" on clients for update using (auth.role() = 'authenticated');
create policy "auth delete" on clients for delete using (auth.role() = 'authenticated');

create policy "auth read" on suppliers for select using (auth.role() = 'authenticated');
create policy "auth write" on suppliers for insert with check (auth.role() = 'authenticated');
create policy "auth update" on suppliers for update using (auth.role() = 'authenticated');
create policy "auth delete" on suppliers for delete using (auth.role() = 'authenticated');

create policy "auth read" on sales for select using (auth.role() = 'authenticated');
create policy "auth write" on sales for insert with check (auth.role() = 'authenticated');
create policy "auth update" on sales for update using (auth.role() = 'authenticated');
create policy "auth delete" on sales for delete using (auth.role() = 'authenticated');

create policy "auth read" on sales_items for select using (auth.role() = 'authenticated');
create policy "auth write" on sales_items for insert with check (auth.role() = 'authenticated');
create policy "auth update" on sales_items for update using (auth.role() = 'authenticated');
create policy "auth delete" on sales_items for delete using (auth.role() = 'authenticated');

create policy "auth read" on purchases for select using (auth.role() = 'authenticated');
create policy "auth write" on purchases for insert with check (auth.role() = 'authenticated');
create policy "auth update" on purchases for update using (auth.role() = 'authenticated');
create policy "auth delete" on purchases for delete using (auth.role() = 'authenticated');

create policy "auth read" on purchases_items for select using (auth.role() = 'authenticated');
create policy "auth write" on purchases_items for insert with check (auth.role() = 'authenticated');
create policy "auth update" on purchases_items for update using (auth.role() = 'authenticated');
create policy "auth delete" on purchases_items for delete using (auth.role() = 'authenticated');
